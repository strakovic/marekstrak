import Script from "next/script";

const Legal = () => {
  const dataUseCases = [
    "Access Logging",
    "Bot Detection",
    "Messaging Form",
    "Marketing Communications",
    "Promotional Offers",
    "Website Analytics",
  ].join(", ");
  return (
    <section
      id="legal"
      className="relative z-10 bg-gray-light py-28 dark:bg-bg-color-dark lg:py-36"
    >
      <div className="container">
        <h1 id="imprint" className="mb-2 text-4xl font-extrabold">
          Imprint
        </h1>
        <p className="mb-3 text-body-color">
          Kandu GmbH
          <br />
          Limited Liability Company (Gesellschaft mit beschr&auml;nkter Haftung)
        </p>
        <p className="mb-3 text-body-color">
          VAT Number (UID): ATU69924549
          <br />
          Company ID (FN): FN 441119 f
          <br />
          Commercial Register (FB-Gericht): Handelsgericht Wien
          <br />
          Registered Office (Sitz): AT, 1220 Wien, Schilfweg 132/3
          <br />
          Business Purpose (Unternehmensgegenstand): IT-Dienstleistungen
          <br />
          Regulatory Framework (Gewerbeordnung): https://www.ris.bka.gv.at/
        </p>
        <p className="mb-3 text-body-color">
          E-Mail: <a href="mailto:hello@billr.io">hello@billr.io</a>
        </p>
      </div>

      <div className="container">
        <h1 id="privacy" className="mb-2 mt-10 text-4xl font-extrabold">
          Privacy Policy
        </h1>
        <p className="mb-3 text-body-color">
          Last Updated: January 1, 2025
          <br />
          Effective Date: January 1, 2025
        </p>
        <p className="mb-3 text-body-color">
          This Privacy Policy describes the policies of Kandu GmbH, Schilfweg
          132/3, Wien 1220, Austria, email:{" "}
          <a href="mailto:hello@billr.io">hello@billr.io</a> on the collection,
          use and disclosure of your information that we collect when you use
          our website ( https://www.billr.io ). (the &ldquo;Service&rdquo;). By
          accessing or using the Service, you are consenting to the collection,
          use and disclosure of your information in accordance with this Privacy
          Policy. If you do not consent to the same, please do not access or use
          the Service.
        </p>
        <p className="mb-3 text-body-color">
          We may modify this Privacy Policy at any time without any prior notice
          to you and will post the revised Privacy Policy on the Service. The
          revised Policy will be effective 180 days from when the revised Policy
          is posted in the Service and your continued access or use of the
          Service after such time will constitute your acceptance of the revised
          Privacy Policy. We therefore recommend that you periodically review
          this page.
        </p>
        <h2 className="mb-2 mt-4 text-3xl font-bold">
          How We Use Your Information
        </h2>
        <p className="mb-3 text-body-color">
          We will use the information that we collect about you for the
          following purposes: {dataUseCases}.
        </p>
        <p className="mb-3 text-body-color">
          If we want to use your information for any other purpose, we will ask
          you for consent and will use your information only on receiving your
          consent and then, only for the purpose(s) for which grant consent
          unless we are required to do otherwise by law.
        </p>
        <h2 className="mb-2 mt-4 text-3xl font-bold">
          How We Share Your Information
        </h2>
        <p className="mb-3 text-body-color">
          We will not transfer your personal information to any third party
          without seeking your consent, except in these limited circumstances:{" "}
          {dataUseCases}.
        </p>
        <p className="mb-3 text-body-color">
          We require such third party&rsquo;s to use the personal information we
          transfer to them only for the purpose for which it was transferred and
          not to retain it for longer than is required for fulfilling the said
          purpose.
        </p>
        <p className="mb-3 text-body-color">
          We may also disclose your personal information for the following: (1)
          to comply with applicable law, regulation, court order or other legal
          process; (2) to enforce your agreements with us, including this
          Privacy Policy; or (3) to respond to claims that your use of the
          Service violates any third-party rights. If the Service or our company
          is merged or acquired with another company, your information will be
          one of the assets that is transferred to the new owner.
        </p>
        <h2 className="mb-2 mt-4 text-3xl font-bold">Your Rights</h2>
        <p className="mb-3 text-body-color">
          Depending on the law that applies, you may have a right to access and
          rectify or erase your personal data or receive a copy of your personal
          data, restrict or object to the active processing of your data, ask us
          to share (port) your personal information to another entity, withdraw
          any consent you provided to us to process your data, a right to lodge
          a complaint with a statutory authority and such other rights as may be
          relevant under applicable laws. To exercise these rights, you can
          write to us at hello@billr.io. We will respond to your request in
          accordance with applicable law.
        </p>
        <p className="mb-3 text-body-color">
          You may opt-out of direct marketing communications or the profiling we
          carry out for marketing purposes by writing to us at hello@billr.io.
        </p>
        <p className="mb-3 text-body-color">
          Do note that if you do not allow us to collect or process the required
          personal information or withdraw the consent to process the same for
          the required purposes, you may not be able to access or use the
          services for which your information was sought.
        </p>
        <h2 className="mb-2 mt-4 text-3xl font-bold">Cookies Etc.</h2>
        <p className="mb-3 text-body-color">
          To learn more about how we use these and your choices in relation to
          these tracking technologies, please refer to our Cookie Policy.
        </p>
        <h2 className="mb-2 mt-4 text-3xl  font-bold">Security</h2>
        <p className="mb-3 text-body-color">
          The security of your information is important to us and we will use
          reasonable security measures to prevent the loss, misuse or
          unauthorized alteration of your information under our control.
          However, given the inherent risks, we cannot guarantee absolute
          security and consequently, we cannot ensure or warrant the security of
          any information you transmit to us and you do so at your own risk.
        </p>
        <h2 className="mb-2 mt-4 text-3xl font-bold">
          Data Protection Officer
        </h2>
        <p className="mb-3 text-body-color">
          If you have any queries or concerns about the processing of your
          information that is available with us, you may email our Data
          Protection Officer at Kandu GmbH, Schilfweg 132/3, 1220 Wien, AT,
          email: hello@billr.io. We will address your concerns in accordance
          with applicable law.
        </p>
      </div>
      <div className="container">
        <h1 id="cookie" className="mb-2 mt-10 text-4xl font-extrabold">
          Cookie Policy
        </h1>
        <p className="mb-3 text-body-color">
          Last Updated: February 1, 2025
          <br />
          Effective Date: February 1, 2025
        </p>
        <p className="mb-3 text-body-color">
          Our website utilizes cookies for: {dataUseCases}. You can find a
          complete list of all cookies and their purpose in the cookie widget.
        </p>
        <p className="mb-3 text-body-color">
          Cookies are small data files stored on your device by websites to
          improve your user experience. According to legal requirements, we can
          save cookies on your device only if they are essential for the
          website&apos;s functionality. For all other cookie types, we require
          your explicit consent.
        </p>
        <p className="mb-3 text-body-color">
          This website employs various kinds of cookies. Some of these are set
          by third-party services integrated into our pages. You have the option
          to modify or revoke your consent at any time via the Cookie
          Declaration on our website.
        </p>
        <p className="mb-3 text-body-color">
          When reaching out to us about your cookie consent, please provide your
          consent ID and the date it was given.
        </p>
      </div>
    </section>
  );
};

export default Legal;

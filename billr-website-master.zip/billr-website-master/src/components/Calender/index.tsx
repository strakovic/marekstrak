"use client";
import Script from "next/script";

const Calendar = () => {
  return (
    <section id="calendar" className="overflow-hidden py-16 md:py-20 lg:py-28">
      <div className="container">
        <div className="-mx-4 flex flex-wrap">
          <div className="w-full px-4 ">
            <div
              className="mb-12 rounded-sm bg-white px-8 py-11 shadow-three dark:bg-gray-dark sm:p-[55px] lg:mb-5 lg:px-8 xl:p-[55px]"
              data-wow-delay=".15s"
            >
              <h2 className="mb-3 pl-8 text-2xl font-bold text-black dark:text-white sm:text-3xl lg:text-2xl xl:text-3xl">
                Book Meeting
              </h2>
              <div
                id="calendly-embed"
                style={{
                  minWidth: "320px",
                  height: "700px",
                  backgroundColor: "#1e232e",
                  colorScheme: "white",
                }}
              ></div>
              <Script
                src="https://assets.calendly.com/assets/external/widget.js"
                onReady={() => {
                  const divEmbed = document.getElementById("calendly-embed");
                  (globalThis.Calendly as any).initInlineWidget({
                    url: "https://calendly.com/dbieringer/billr-intro-call?background_color=1e232e&text_color=FFFFFF&primary_color=4a6cf7",
                    parentElement: divEmbed,
                  });
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Calendar;

"use client";
import ToggleableSection from "@/app/toggle/ToggleableSection";
import { useState } from "react";
import { FaCheck } from "react-icons/fa";

const FeatureSection = () => {
  const [showFinancialPoints, setShowFinancialPoints] = useState(false);
  const [showIntegrationPoints, setShowIntegrationPoints] = useState(false);
  const [showWorkflowPoints, setShowWorkflowPoints] = useState(false);
  const [showAuditPoints, setShowAuditPoints] = useState(false);

  const toggleFinancialPoints = (event: React.MouseEvent) => {
    event.preventDefault();
    setShowFinancialPoints(!showFinancialPoints);
  };

  const toggleIntegrationPoints = (event: React.MouseEvent) => {
    event.preventDefault();
    setShowIntegrationPoints(!showIntegrationPoints);
  };

  const toggleWorkflowPoints = (event: React.MouseEvent) => {
    event.preventDefault();
    setShowWorkflowPoints(!showWorkflowPoints);
  };
  const toggleAuditPoints = (event: React.MouseEvent) => {
    event.preventDefault();
    setShowAuditPoints(!showAuditPoints);
  };

  return (
    <section className=" border-t border-body-color/[.15] bg-black pb-16 pb-6 dark:border-white/[.15]">
      <div className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8">
        <div className="container mx-auto  bg-black p-6">
          <div className="mb-16  text-center">
            <h1 className="text-base font-semibold uppercase tracking-wide text-indigo-600">
              Solutions by Role
            </h1>
            <p className="mt-2 text-5xl font-bold tracking-tight text-white lg:text-5xl">
              We empower every role with <br />
              innovative solutions
            </p>
          </div>
          <div className="my-12 flex flex-wrap ">
            <div className="w-full border-b p-8 md:w-1/2 md:border-r lg:w-1/3">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">CFO</div>
              </div>
              <ToggleableSection
                title="As a financial leader, you need accurate, timely data to make strategic decisions."
                items={[
                  "Real-time financial insights and forecasting capabilities",
                  "Automated revenue recognition and compliance tracking",
                  "Comprehensive financial reporting and analytics",
                  "Improved cash flow management through efficient billing processes",
                ]}
              />
            </div>
            <div className="w-full border-b p-8 md:w-1/2 lg:w-1/3 lg:border-r">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">CTO</div>
              </div>
              <ToggleableSection
                title="Enhance your infrastructure with our state-of-the-art solutions."
                items={[
                  "Seamless integration with existing IT infrastructure",
                  "Scalable, cloud-based architecture for future growth",
                  "Robust API for custom integrations and automations",
                  "Enterprise-grade security to protect sensitive financial data",
                ]}
              />
            </div>
            <div className="w-full border-b p-8 md:w-1/2 md:border-r lg:w-1/3 lg:border-r-0">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">Head of Operations</div>
              </div>
              <ToggleableSection
                title="Streamline your billing operations for maximum efficiency."
                items={[
                  "Seamless integration with existing IT infrastructure",
                  "Scalable, cloud-based architecture for future growth",
                  "Robust API for custom integrations and automations",
                  "Enterprise-grade security to protect sensitive financial data",
                ]}
              />
            </div>
            <div className="w-full border-b p-8 md:w-1/2 lg:w-1/3 lg:border-b-0 lg:border-r">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">Financial Controllers</div>
              </div>
              <ToggleableSection
                title="Maintain financial accuracy and compliance with ease."
                items={[
                  "Automated checks and balances to ensure data integrity",
                  "Detailed audit trails for all transactions and changes",
                  "Customizable controls and approval processes",
                  "Comprehensive reporting for internal and external audits",
                ]}
              />
            </div>
            <div className="w-full border-b p-8 md:w-1/2 md:border-b-0 md:border-r lg:w-1/3 lg:border-b-0">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">Product Managers</div>
              </div>
              <ToggleableSection
                title="Empower your sales team with flexible, responsive billing capabilities."
                items={[
                  "Quickly launch new products with diverse pricing models",
                  "Gain insights into product usage and performance",
                  "IImplement usage-based and tiered pricing strategies",
                  "A/B test different pricing structures to optimize revenue",
                ]}
              />
            </div>
            <div className="w-full p-8 md:w-1/2 lg:w-1/3">
              <div className="mb-6 flex items-center">
                <FaCheck
                  width={20}
                  height={20}
                  fill="currentColor"
                  className="h-6 w-6 text-indigo-500"
                />
                <div className="ml-4 text-xl">Sales Teams</div>
              </div>
              <ToggleableSection
                title="Empower your sales team with flexible, responsive billing capabilities."
                items={[
                  "Quick implementation of new pricing models and promotions",
                  "Real-time quoting and contract management",
                  "Integration with CRM systems for a 360-degree customer view",
                  "Accelerated quote-to-cash cycles",
                ]}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default FeatureSection;

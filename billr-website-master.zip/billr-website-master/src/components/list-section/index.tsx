import Image from "next/image";

const listItems = [
  {
    title: `Enterprise`,
    description: `Large organizations require robust, scalable solutions.`,
    additionalText: `dddd`,
  },
  {
    title: `SMEs`,
    description: `Growing businesses need flexibility and efficiency.`,
    additionalText: `dddd`,
  },
];

const checkIcon = (
  <svg width="16" height="13" viewBox="0 0 16 13" className="fill-current">
    <path d="M5.8535 12.6631C5.65824 12.8584 5.34166 12.8584 5.1464 12.6631L0.678505 8.1952C0.483242 7.99994 0.483242 7.68336 0.678505 7.4881L2.32921 5.83739C2.52467 5.64193 2.84166 5.64216 3.03684 5.83791L5.14622 7.95354C5.34147 8.14936 5.65859 8.14952 5.85403 7.95388L13.3797 0.420561C13.575 0.22513 13.8917 0.225051 14.087 0.420383L15.7381 2.07143C15.9333 2.26669 15.9333 2.58327 15.7381 2.77854L5.8535 12.6631Z" />
  </svg>
);

const List = ({ text }) => (
  <p className="mb-5 flex items-center text-lg font-medium text-body-color">
    <span className="mr-4 flex h-[30px] w-[30px] items-center justify-center rounded-md bg-primary bg-opacity-10 text-primary">
      {checkIcon}
    </span>
    {text}
  </p>
);

const ListSection = () => (
  <section className="overflow-hidden pt-28 lg:py-28">
    <div className="mx-auto max-w-7xl bg-black p-4 sm:p-6 lg:p-8">
      <div className="mb-16 text-center">
        <h1 className="text-base font-semibold uppercase tracking-wide text-indigo-600">
          Solutions by Company Size
        </h1>
        <p className="mt-2 pb-4 text-5xl font-bold tracking-tight text-white lg:text-5xl">
          From Growing Businesses to
          <br /> Large Organizations
        </p>
      </div>
      <div className="flex items-center justify-center">
        <div className="w-1/2 p-4">
          <div className="flex items-center justify-center">
            <h1 className="text-center text-3xl font-semibold tracking-wide">
              Enterprise
            </h1>
          </div>
          <p className="pb-8  pt-8 text-center text-xl text-body-color">
            Large organizations require robust, scalable solutions
          </p>
          <div className="  w-full  items-center justify-center sm:w-1/2 lg:w-full">
            <List text="High-volume transaction processing" />
            <List text="Advanced integration capabilities with existing enterprise systems" />
            <List text="Comprehensive reporting and analytics for strategic decision-making" />
            <List text="Enterprise-grade security and compliance features" />
          </div>
        </div>
        <div className="w-1/2 p-4">
          <h1 className="text-center text-3xl font-semibold tracking-wide">
            SMEs
          </h1>
          <p className="pb-8  pr-8 pt-8 text-center  text-xl text-body-color">
            Growing businesses need flexibility and efficiency
          </p>
          <div className="w-full  sm:w-1/2 lg:w-full ">
            <List text="High-volume transaction processing" />
            <List text="Advanced integration capabilities with existing enterprise systems" />
            <List text="Comprehensive reporting and analytics for strategic decision-making" />
            <List text="Enterprise-grade security and compliance features" />
          </div>
        </div>
      </div>
    </div>
  </section>
);
export default ListSection;

"use client";
import { useState } from "react";
import FeaturesTabItem from "./FeaturesTabItem";
import featuresTabData from "./featuresTabData";

const FeaturesTab = () => {
  const [currentTab, setCurrentTab] = useState("tabOne");

  return (
    <>
      {/* <!-- ===== Features Tab Start ===== --> */}
      <section id="featuresTab" className="pt-18.5 lg:pb-22.5 relative pb-20">
        <div className="w-full px-4 ">
          <h1 className="font-semi    pb-14 pt-28 text-center text-5xl font-bold  capitalize tracking-wide">
            About Us
          </h1>
        </div>
        <div className=" max-w-c-1390 relative mx-auto  px-4 md:px-8 2xl:px-0">
          <div className="animate_top mb-15 border-stroke shadow-solid-5 dark:border-strokedark dark:bg-blacksection dark:shadow-solid-6 lg:gap-7.5 xl:mb-21.5 xl:gap-12.5 flex flex-wrap justify-center rounded-[10px]  md:flex-nowrap md:items-center">
            <div
              onClick={() => setCurrentTab("tabOne")}
              className={`border-stroke dark:border-strokedark xl:px-13.5 relative flex w-full cursor-pointer items-center gap-4 border-b px-6 py-2 last:border-0 md:w-auto md:border-0 xl:py-5 ${
                currentTab === "tabOne"
                  ? "active before:absolute before:bottom-0 before:left-0 before:h-1 before:w-full before:rounded-tl-[4px] before:rounded-tr-[4px] before:bg-primary"
                  : ""
              }`}
            >
              <div className="md:w-3/5 lg:w-auto">
                <button className="xl:text-regular   text-xl font-medium text-black  dark:text-white">
                  Our Story
                </button>
              </div>
            </div>
            <div
              onClick={() => setCurrentTab("tabTwo")}
              className={`border-stroke dark:border-strokedark xl:px-13.5 relative flex w-full cursor-pointer items-center gap-4 border-b px-6 py-2 last:border-0 md:w-auto md:border-0 xl:py-5 ${
                currentTab === "tabTwo"
                  ? "active before:absolute before:bottom-0 before:left-0 before:h-1 before:w-full before:rounded-tl-[4px] before:rounded-tr-[4px] before:bg-primary"
                  : ""
              }`}
            >
              <div className="md:w-3/5 lg:w-auto ">
                <button className="xl:text-regular text-xl   font-medium text-black  dark:text-white">
                  Our Mission
                </button>
              </div>
            </div>
            <div
              onClick={() => setCurrentTab("tabThree")}
              className={`border-stroke dark:border-strokedark xl:px-13.5 relative flex w-full cursor-pointer items-center gap-4 border-b px-6 py-2 last:border-0 md:w-auto md:border-0 xl:py-5 ${
                currentTab === "tabThree"
                  ? "active before:absolute before:bottom-0 before:left-0 before:h-1 before:w-full before:rounded-tl-[4px] before:rounded-tr-[4px] before:bg-primary"
                  : ""
              }`}
            >
              <div className="md:w-3/5 lg:w-auto">
                <button className="xl:text-regular  text-xl font-medium  text-black  dark:text-white">
                  Our Vision
                </button>
              </div>
            </div>
          </div>
          <div className="max-w-c-1154 mx-auto">
            {featuresTabData.map((feature, key) => (
              <div
                className={feature.id === currentTab ? "block" : "hidden"}
                key={key}
              >
                <FeaturesTabItem featureTab={feature} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default FeaturesTab;

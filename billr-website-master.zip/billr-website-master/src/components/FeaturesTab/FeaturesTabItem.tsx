import React from "react";
import { FeatureTab } from "@/types/featureTab";

const FeaturesTabItem = ({ featureTab }: { featureTab: FeatureTab }) => {
  const { title, desc1, desc2, image, imageDark } = featureTab;

  return (
    <>
      <div className="px-auto flex flex-col items-center justify-center gap-60 py-36 md:flex-row">
        <div className="text-center md:w-1/2">
          <h2 className="xl:text-sectiontitle2 mb-7 text-3xl font-bold text-black dark:text-white">
            {title}
          </h2>
          <p className="mb-5 text-black dark:text-body-color">{desc1}</p>
          <p className="w-11/12">{desc2}</p>
        </div>
      </div>
    </>
  );
};

export default FeaturesTabItem;

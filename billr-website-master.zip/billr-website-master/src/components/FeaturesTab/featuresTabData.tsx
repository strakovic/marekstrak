import { FeatureTab } from "@/types/featureTab";

const featuresTabData: FeatureTab[] = [
  {
    id: "tabOne",
    title: "Turning Billing Challenges into Opportunities",
    desc1: `Billr was born from a deep understanding of the challenges faced by businesses in managing complex billing processes. Our founders, having experienced these pain points firsthand in their ventures, set out to create a solution that would transform billing from a necessary evil into a strategic asset.`,
    desc2: ``,
    image: "/images/about/about-image.svg",
    imageDark: "/images/about/about-image-dark.svg",
  },
  {
    id: "tabTwo",
    title: "Empowering Businesses with Smarter Billing",
    desc1: `At Billr, our mission is to empower businesses to thrive by simplifying and optimizing their billing processes. We believe that billing should be a catalyst for growth, not a hindrance to progress. By providing innovative, flexible, and reliable billing solutions, we aim to free our clients from the shackles of outdated systems and manual processes, allowing them to focus on what truly matters – growing their business and serving their customers.`,
    desc2: ``,
    image: "/images/about/about-image.svg",
    imageDark: "/images/about/about-image-dark.svg",
  },
  {
    id: "tabThree",
    title: "Revolutionizing Billing for a Smarter Future",
    desc1: `We envision a world where billing is no longer a source of frustration and inefficiency, but a powerful tool for business insight and strategic decision-making. Billr is committed to being at the forefront of this transformation, continuously innovating to meet the evolving needs of businesses across industries.`,
    desc2: ``,
    image: "/images/about/about-image.svg",
    imageDark: "/images/about/about-image-dark.svg",
  },
];

export default featuresTabData;

import { Menu } from "@/types/menu";

const menuData: Menu[] = [
  {
    id: 1,
    title: "Home",
    path: "/",
    newTab: false,
  },
  {
    id: 368,
    title: "Feature",
    path: "/#features",
    newTab: false,
  },
  {
    id: 4,
    title: "About",
    path: "/#featuresTab",
    newTab: false,
  },
  {
    id: 5,
    title: "Contact",
    path: "/#contact",
    newTab: false,
  },
  {
    id: 33,
    title: "Legal",
    path: "/legal",
    newTab: false,
  },
];
export default menuData;

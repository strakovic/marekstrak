import Image from "next/image";
import SectionTitle from "../Common/SectionTitle";

const checkIcon = (
  <svg width="16" height="13" viewBox="0 0 16 13" className="fill-current">
    <path d="M5.8535 12.6631C5.65824 12.8584 5.34166 12.8584 5.1464 12.6631L0.678505 8.1952C0.483242 7.99994 0.483242 7.68336 0.678505 7.4881L2.32921 5.83739C2.52467 5.64193 2.84166 5.64216 3.03684 5.83791L5.14622 7.95354C5.34147 8.14936 5.65859 8.14952 5.85403 7.95388L13.3797 0.420561C13.575 0.22513 13.8917 0.225051 14.087 0.420383L15.7381 2.07143C15.9333 2.26669 15.9333 2.58327 15.7381 2.77854L5.8535 12.6631Z" />
  </svg>
);

const AboutSectionOne = () => {
  const List = ({ text }) => (
    <p className="mb-5 flex items-center text-lg font-medium text-body-color">
      <span className="mr-4 flex h-[30px] w-[30px] items-center justify-center rounded-md bg-primary bg-opacity-10 text-primary">
        {checkIcon}
      </span>
      {text}
    </p>
  );

  return (
    <section
      id="about"
      className="border-b border-t border-body-color/[.15] pb-0 pb-16  pt-16 dark:border-white/[.15] "
    >
      <div className="container flex justify-center">
        <div className="border-body-color/[.15] pb-0  dark:border-white/[.15] ">
          <div className="-mx-4 flex flex-wrap items-center">
            <div className="w-full px-4 ">
              <h1 className="font-semi text-center text-base font-bold uppercase tracking-wide text-indigo-600">
                Solutions by Industry
              </h1>
              <p className="mb-8 mt-2 text-center text-5xl font-bold tracking-tight text-white lg:text-5xl">
                Solutions for Every Industry
              </p>
              <p className="lg:text-l mb-8 text-center text-xl  tracking-tight text-body-color">
                Billr simplifies complex billing for industries that demand
                precision, flexibility, and scalability.
              </p>
              {/*   title="Tailored Billing Solutions for Every Industry"
                paragraph="Billr simplifies complex billing for industries that demand precision, flexibility, and scalability."
                mb="44px"
              /> */}

              <div
                className="m-auto mb-12 max-w-[570px] p-4"
                data-wow-delay=".15s"
              >
                <div className="mx-[-12px] mb-0 flex flex-wrap pb-0 ">
                  <div className="w-full justify-center px-3 sm:w-1/2 lg:w-full xl:w-1/2">
                    <List text="Telecommunications" />
                    <List text="Utilities" />
                    <List text="Logistics" />
                    <List text="Professional Services" />
                  </div>

                  <div className="w-full justify-center px-3 sm:w-1/2 lg:w-full xl:w-1/2">
                    <List text="SaaS" />
                    <List text="Healthcare" />
                    <List text="E-commerce & Retail " />
                    <List text="Manufacturing " />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSectionOne;

"use client";
import Script from "next/script";

const Contact = () => {
  return (
    <>
      <section id="contact" className="overflow-hidden py-16 md:py-20 lg:py-28">
        <div className="container">
          <div className="-mx-4 flex flex-wrap">
            <div className="w-full px-4 ">
              <div
                className="mb-12 rounded-sm bg-white px-8 py-11 shadow-three dark:bg-gray-dark sm:p-[55px] lg:mb-5 lg:px-8 xl:p-[55px]"
                data-wow-delay=".15s"
              >
                <h2 className="mb-3 pl-8 text-2xl font-bold text-black dark:text-white sm:text-3xl lg:text-2xl xl:text-3xl">
                  Contact Us
                </h2>
                <div className="pl-8 pr-8">
                  <iframe
                    data-tally-src="https://tally.so/embed/wb6017?alignLeft=1&hideTitle=1&dynamicHeight=1"
                    loading="lazy"
                    width="100%"
                    height="100"
                  ></iframe>
                  <Script
                    src="https://tally.so/widgets/embed.js"
                    onReady={() => {
                      (globalThis.Tally as any).loadEmbeds();
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;

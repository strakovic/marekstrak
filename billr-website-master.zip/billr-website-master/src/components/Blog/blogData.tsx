import { Blog } from "@/types/blog";

const blogData: Blog[] = [
  {
    id: 1,
    title: "Increased Efficiency",
    paragraph:
      "Automate complex billing processes, reducing manual work and freeing up your team for strategic tasks.",
    image: "/images/blog/efficiency.jpg",
  },
  {
    id: 2,
    title: "Enhanced Accuracy",
    paragraph:
      "Minimize errors and discrepancies in your billing, improving customer satisfaction and financial integrity.",
    image: "/images/blog/accuracy.jpg",
  },
  {
    id: 3,
    title: "Real-Time Insights",
    paragraph:
      "Make informed decisions with up-to-the-minute financial data and comprehensive reporting.",
    image: "/images/blog/realTime.jpg",
  },
  {
    id: 4,
    title: "Scalability",
    paragraph:
      "Grow your business without worrying about your billing system keeping pace.",
    image: "/images/blog/scalability.jpg",
  },
  {
    id: 5,
    title: "Improved Cash Flow",
    paragraph:
      "Accelerate your quote-to-cash cycle with faster, more accurate billing.",
    image: "/images/blog/money.jpg",
  },
  {
    id: 6,
    title: "Customization",
    paragraph:
      "Adapt the system to your unique business needs without expensive custom development.",
    image: "/images/blog/customization.jpg",
  },
];
export default blogData;

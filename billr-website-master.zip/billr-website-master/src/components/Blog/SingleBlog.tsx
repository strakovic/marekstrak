import { Blog } from "@/types/blog";

const SingleBlog = ({ blog }: { blog: Blog }) => {
  const { title, image, paragraph } = blog;
  return (
    <>
      <div className="group relative flex h-full flex-col overflow-hidden rounded-sm bg-white shadow-one duration-300 hover:shadow-two dark:bg-dark dark:hover:shadow-gray-dark">
        <div className="relative block aspect-[37/22] w-full">
          <img src={image} alt="image" />
        </div>
        <div className="flex-1 p-6 sm:p-8 md:px-6 md:py-8 lg:p-8 xl:px-5 xl:py-8 2xl:p-8">
          <h3 className="mb-4 block text-xl font-bold text-black hover:text-primary dark:text-white dark:hover:text-primary sm:text-2xl">
            {title}
          </h3>
          <p className="mb-6 pb-6 text-base font-medium text-body-color">
            {paragraph}
          </p>
        </div>
      </div>
    </>
  );
};

export default SingleBlog;

import React, { useState } from "react";

interface ToggleableSectionProps {
  title: string;
  items: string[];
}

const ToggleableSection: React.FC<ToggleableSectionProps> = ({
  title,
  items,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSection = (event: React.MouseEvent) => {
    event.preventDefault();
    setIsOpen(!isOpen);
  };

  return (
    <div className="toggleable-section">
      <p className="mt-4 leading-loose text-gray-500">{title}</p>
      <a href="#" onClick={toggleSection} className="text-blue-500">
        {isOpen ? "Read less" : "Read more"}
      </a>
      {isOpen && (
        <ul className="list-inside list-disc text-gray-500">
          {items.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ToggleableSection;

import AboutSectionOne from "@/components/About/AboutSectionOne";
import AboutPageTwo from "@/components/About/aboutPageTwo";
import AboutPageThree from "@/components/About/aboutPageThree";
import Blog from "@/components/Blog";
import Contact from "@/components/Contact";
import Features from "@/components/Features";
import FeaturesTab from "@/components/FeaturesTab";
import Hero from "@/components/Hero";
import Video from "@/components/Video";
import FeatureSection from "@/components/feature-section";
import ListSection from "@/components/list-section";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Billr",
  description:
    "Billr is a cutting-edge billing solution designed to meet the complex needs of modern enterprises.",
};

export default function Home() {
  return (
    <>
      <Hero />
      <Video />
      <FeatureSection />
      <AboutSectionOne />
      <ListSection />
      <Features />
      <FeaturesTab />
      <AboutPageTwo />
      <AboutPageThree />
      <Blog />
      <Contact />
    </>
  );
}
